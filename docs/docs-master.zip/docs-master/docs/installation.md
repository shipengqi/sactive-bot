# Installation 

## As RPM package (for redhat-based systems)

Use the `rpm` tool to install the rpm file that you have downloaded.

```bash
rpm -i hubot-enterprise-<version>-<release>.<arch>.rpm
```
