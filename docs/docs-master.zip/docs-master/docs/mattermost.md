#  Using HE with Mattermost  

> **Pre-requisite**: Before you can use `Hubot Enterprise` with the `matteruser`
> adapter you need to have a `mattermost` **server** running in a 
> local or remote machine. If you do not have a server already you may
> follow the instructions on this [guide](mattermost_setup.md) to setup
> your own.


## Installation
* Install `nodejs6` (should include `npm` package manager).
  * If you are installing in an environment subject to an **http proxy**,
    You _must_ configure `npm` client to respect proxy values as such:

    ```shell
    npm config set http-proxy http://your-proxy.com:8080/
    npm config set https-proxy http://your-proxy.com:8080/
    npm config set proxy http://your-proxy.com:8080/
    npm config set strict-ssl false
    ```

    For more info, please visit the [npm config docs](https://docs.npmjs.com/cli/config).

* Install `yarn` and `coffeescript`: `npm install -g yarn coffee-script`.
* Clone this repository.
* Install project dependencies: `cd hubot-enterprise && yarn`.


## Running the bot
You need to `export` the following environment variables before running 
HE with `./run.sh`:
* `MATTERMOST_HOST` - the `mattermost` hostname without port or protocol, just the name.
* `MATTERMOST_GROUP` - the `mattermost` group to which your bot belongs.
* `MATTERMOST_USER` - the email address that was used to create the hubot user.
* `MATTERMOST_PASSWORD` - the password that was created for the bot
* `HUBOT_NAME` - the name of the bot, should be the same as the `username` part of the `MATTERMOST_USER` value. Example: If `MATTERMOST_USER=bot@hpe.com` then export `HUBOT_NAME=bot`.
* `HUBOT_ADAPTER=unified-mattermost` - this tells `Hubot Enterprise` to use the `unified-mattermost` adapter, so it can connect to the `mattermost` **server**.

### For an http port other than 80
Set the following variable:
* `MATTERMOST_HTTP_PORT` - the port in which your `mattermost` listens for http requests
    
### For a `mattermost` server that doesn't use encrypted communications
Set the following variables so that `hubot` will communicate through unsecure sockets:
* `MATTERMOST_USE_TLS`=false
* `MATTERMOST_TLS_VERIFY`=false
* `MATTERMOST_WSS_PORT` - the port for wss communications, if you don't use ssl the default is 80(the same as http) or 443 if you use ssl, but it can be configured. This value should be the same as the value in your mattermost configuration.

> This is **only** recommended for a development / testing purposes.


### For a `mattermost` server uses a self-signed ssl certificate
Set these variables in order to connect:
* `MATTERMOST_USE_TLS`=true
* `MATTERMOST_TLS_VERIFY`=false
* `MATTERMOST_WSS_PORT` - the port for wss communications, if you don't use ssl the default is 80(the same as http) or 443 if you use ssl, but it can be configured. This value should be the same as the value in your mattermost configuration.

> This is **only** recommended for a development / testing purposes.



### For a `mattermost` server uses an ssl certificate signed by a trusted authority 
Set these variables in order to connect:
* `MATTERMOST_USE_TLS`=true
* `MATTERMOST_TLS_VERIFY`=true
* `MATTERMOST_WSS_PORT` - the port for wss communications, if you don't use ssl the default is 80(the same as http) or 443 if you use ssl, but it can be configured. This value should be the same as the value in your mattermost configuration.

> This is the recommended way to set up your server for production.

### Optional environment variables
Here are some environment variables you dont need to setup, but you can set them if you want:

* `MATTERMOST_REPLY` - defaults to true. set it to false to stop posting `reply` responses as comments
* `MATTERMOST_IGNORE_USERS` - defaults to empty. Enter a  comma-separated list of user senderi_names to ignore.

After you have setup all your environment variables you can start HE with `./run.sh`

For more information see the official [hubot-matteruser](https://github.com/loafoe/hubot-matteruser) documentation.
