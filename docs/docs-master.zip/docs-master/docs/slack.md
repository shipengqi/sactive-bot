# Using HE with Slack 

> **Note**: `HUBOT_ADAPTER` should be set now to `unified-slack` to
> use the unified adapter API. `HUBOT_ADAPTER=slack` will be used
> only for development and will be **depracated**.

## Option 1: Linux 

### Linux Installation

* Install `nodejs6` (should include `npm` package manager).
  * If you are installing in an environment subject to an **http proxy**,
    You _must_ configure `npm` client to respect proxy values as such:

    ```shell
    npm config set http-proxy http://your-proxy.com:8080/
    npm config set https-proxy http://your-proxy.com:8080/
    npm config set proxy http://your-proxy.com:8080/
    npm config set strict-ssl false
    ```

    For more info, please visit the [npm config docs](https://docs.npmjs.com/cli/config).
    
* Install `yarn` and `coffeescript`: `npm install -g yarn coffee-script`.
* Clone this repository.
* Install project dependencies: `cd hubot-enterprise && yarn`.

### Run Bot with Linux

There are two options to configure hubot enterprise to connect and
issue commands to Slack, in order of precedence:

* Option A: Use **existing** bot token with slack API token 
  (For development)
* Option B: Use oauth process to generate bot token and slack API token 
  (For development and production)

#### Option A: Use existing bot token and slack API token

> This is recommended **only** for development.

Generate two different tokens. You need to login to slack in your 
browser for the following steps:

* Get a **bot token** by 
  [installing hubot integration](https://slack.com/apps/A0F7XDU93-hubot)
   in your team.
* Get an **API token** by using 
  [this dashboard](https://api.slack.com/docs/oauth-test-tokens) for  
  your team.

Set the **bot token** with `HUBOT_SLACK_TOKEN` env var and set 
the slack **API token** with `HUBOT_SLACK_API_TOKEN` env var:

```shell
# Set your bot's name
export HUBOT_NAME=...
# Specify that you are using slack
export HUBOT_ADAPTER=unified-slack
# Bot token:
export HUBOT_SLACK_TOKEN=xoxb-...
# API token:
export HUBOT_SLACK_API_TOKEN=xoxp-...

# Run
cd hubot-enterprise && ./run.sh
```

> Your tokens **will not** be persisted to the file system.

#### Option B: Use oauth process to generate bot / api tokens
  
> This is recommended for **both** development and production.

If you are creating a [slack app](https://api.slack.com/slack-apps) 
specify your slack app client id and secrets.

The authorization of an app with a team as described in the Slack 
documentation requires the user that is installing the bot to 
manually navigate to the login url that is provided using a desktop 
browser to follow the *web oauth flow*.

We have provided a new automated way to do this with **no** 
user intervention. This is accomplished by specifying the name of your 
slack team (`HUBOT_SLACK_APP_TEAM_NAME`), an admin username 
(`HUBOT_SLACK_APP_TEAM_USERNAME`), and that username's password 
(`HUBOT_SLACK_APP_TEAM_USERPASS`).

```shell
# Specify that you are using slack
export HUBOT_ADAPTER=slack
# Specify the slack app details:
# This is the name that you used in the slack app registration dashboard
export HUBOT_NAME=...
# Copy this client id string from the slack app registration dashboard
export HUBOT_SLACK_APP_CLIENT_ID=...
# Copy this client id string from the  slack app registration dashboard
export HUBOT_SLACK_APP_SECRET=...

# WARNING: the following two values should be consistent with the 
# values entered in the Slack dashboard.
# Specify the hostname or IP of the machine /host in which you are running the container/server
# Default = 127.0.0.1
export HUBOT_SLACK_OAUTH2_WEBSERVER_HOSTNAME=localhost
# Specify the port of the machine / host in which you are running the container/server
# Default = 4000
export HUBOT_SLACK_OAUTH2_WEBSERVER_PORT=3000

# *** new env vars ***
# Your slack team's domain name
export HUBOT_SLACK_APP_TEAM_NAME="..."
# Email / username with admin access to the team (to be able to add app to team)
export HUBOT_SLACK_APP_TEAM_USERNAME="..."
# The password for that account. 
export HUBOT_SLACK_APP_TEAM_USERPASS="..."

cd hubot-enterprise && ./run.sh
```

> Your tokens will be persisted in `./config/slack-app.json`.

> **WARNING:** Using this method could potentially be a security risk 
> since you are passing your slack credentials. It is highly recommended
> that you change the password for that account after running the setup 
> and also, shutting down the bot and clearing your environment after 
> caching the tokens in your local environment,
> i.e. `/slack_app_db` and `slack-app.json`. 

---

## Option 2: Docker
 
> Docker installation and deployment is not supported anymore and it
> does **not** need to be tested by QA.

### Docker Installation

* Install docker for your [Linux distribution](https://docs.docker.com/engine/installation/#/on-linux)
* Clone the `hubot-enterprise` [repo](https://github.hpe.com/he-chatops/hubot-enterprise)
* Login to HPE Docker Hub: `docker login hub.docker.hpecorp.net`
* Build docker image `he`

  ```shell
  cd hubot-enteprise && docker build -t he .
  ```

  If you are building within an environment subject to an **http proxy**,
  you _must_ use docker's `build-arg` flags to add the different 
  _proxy_ and _no_proxy_ arguments. For instance:

  ```shell
  # Assuming that you have all these proxy env vars set in your environment
  cd hubot-enteprise && docker build \
    --build-arg="http_proxy=$http_proxy" \
    --build-arg="https_proxy=$https_proxy" \
    --build-arg="no_proxy=$no_proxy" \
    --build-arg="HTTP_PROXY=$HTTP_PROXY" \
    --build-arg="HTTPS_PROXY=$HTTPS_PROXY" \
    --build-arg="NO_PROXY=$NO_PROXY" \
    -t he .
  ```

### Run Bot with Docker

There are two options to configure hubot enterprise to connect and
issue commands to Slack, in order of precedence:

* Option A: Use **existing** bot token with slack API token 
  (For development)
* Option B: Use oauth process to generate bot token and slack API token 
  (For development and production)

> If you are running the container within an environment subject 
> to an **http proxy**,
> you _must_ use docker's `-e` flags to add the different 
> _proxy_ and _no_proxy_ as environment variables. For instance:

#### Option A: Use existing bot token and slack API token
  
```shell
# Set bot's name
export HUBOT_NAME=...
# Set bot token:
export HUBOT_SLACK_TOKEN=xoxb-...
# Set api token
export HUBOT_SLACK_API_TOKEN=xoxp-...
# Set adapter type
export HUBOT_ADAPTER=unified-slack
# Run container
docker run -it \ 
-e HUBOT_SLACK_TOKEN=$HUBOT_SLACK_TOKEN \
-e HUBOT_SLACK_API_TOKEN=$HUBOT_SLACK_API_TOKEN \
-e HUBOT_NAME=$HUBOT_NAME \
-e HUBOT_ADAPTER=$HUBOT_ADAPTER \
-e HTTP_PROXY=$HTTP_PROXY \
-e HTTPS_PROXY=$HTTPS_PROXY \
-e NO_PROXY=$NO_PROXY \
-e http_proxy=$http_proxy \
-e https_proxy=$https_proxy \
-e no_proxy=$no_proxy \
he
```

> Replace `-it` with `-d` to launch bot in the background.  

#### Option B: Use oauth process to generate bot / api tokens

If you are creating a [slack app](https://api.slack.com/slack-apps) 
specify your slack app client id and secrets.

The authorization of an app with a team as described in the slack docs 
requires the user that is installing the bot to manually navigate to 
the login url that is provided using a desktop browser to follow the 
*web oauth flow*.

We have provided a new automated way to do this with **no** user 
intervention. This is accomplished by specifying the name of your 
slack team (`HUBOT_SLACK_APP_TEAM_NAME`), an admin username 
(`HUBOT_SLACK_APP_TEAM_USERNAME`), and that username's password 
(`HUBOT_SLACK_APP_TEAM_USERPASS`).

Also, make sure that the `HUBOT_SLACK_OAUTH2_WEBSERVER_HOSTNAME` and 
`HUBOT_SLACK_OAUTH2_WEBSERVER_PORT` values match those from the slack 
app dashboard **and** are the same as the *host's* (machine) in which 
you are running the containers, i.e. do not use `localhost` or 
`127.0.0.1` because those refer to the container and not the host.

Also make sure that `HUBOT_SLACK_OAUTH2_WEBSERVER_PORT` is a port 
that is available on your host.

```shell
# Assuming there are proxy environment variables
# Asuming all these HUBOT_* environment variables are set as above.
docker run -it \
-e HUBOT_ADAPTER=$HUBOT_ADAPTER \
-e HUBOT_NAME=$HUBOT_NAME  \
-e HUBOT_SLACK_APP_CLIENT_ID=$HUBOT_SLACK_APP_CLIENT_ID \
-e HUBOT_SLACK_APP_SECRET=$HUBOT_SLACK_APP_SECRET \
-e HUBOT_SLACK_APP_TEAM_NAME=$HUBOT_SLACK_APP_TEAM_NAME \
-e HUBOT_SLACK_APP_TEAM_USERNAME=$HUBOT_SLACK_APP_TEAM_USERNAME \
-e HUBOT_SLACK_APP_TEAM_USERPASS=$HUBOT_SLACK_APP_TEAM_USERPASS \
-e HUBOT_SLACK_OAUTH2_WEBSERVER_HOSTNAME=$HUBOT_SLACK_OAUTH2_WEBSERVER_HOSTNAME \
-e HUBOT_SLACK_OAUTH2_WEBSERVER_PORT=$HUBOT_SLACK_OAUTH2_WEBSERVER_PORT \
-e HTTP_PROXY=$HTTP_PROXY \
-e HTTPS_PROXY=$HTTPS_PROXY \
-e NO_PROXY=$NO_PROXY \
-e http_proxy=$http_proxy \
-e https_proxy=$https_proxy \
-e no_proxy=$no_proxy \
-v $PWD/config/:/he/config \
-p $HUBOT_SLACK_OAUTH2_WEBSERVER_PORT:$HUBOT_SLACK_OAUTH2_WEBSERVER_PORT 
he
```

You will see a server startup at the *hostname* and *port* that you
specified (or default ones). Our startup script will go through the
oauth process and inject the tokens before starting hubot enterprise.

> Note that tokens are persisted on the host by mounting on top of the
> `/he/config` directory in the container.
