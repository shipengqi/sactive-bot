# Developer Guide

## What is Hubot

`hubot` is an open source _chat bot_ or just _bot_ that can be extended using 
integration scripts. It was originally developed by **Github**. In this 
document we describe how you may use our `Hubot Enterprise` or `he` bot
which is an enterprise-ready extension of `hubot` to build your product scripts.
For background information of `hubot` please refer to its project [page](https://hubot.github.com/).

> **Important Note:** Please make sure that you read this document carefully
> to understand the differences between `hubot` and `Hubot Enterprise`.

## What is Hubot Enterprise

Hubot Enterprise (the `he`) is an evolution of the open source
`hubot` project. We have customized it and extended it to provide
a suitable 'bot` ecosystem for your products. Here is a brief list
of the features and extensions that we have built:

* `UnifiedAdapter` - a _unified_ (standardized) communication adapter 
  between the `he` and the `chat platform` (e.g. `slack`, `mattermost`
  , `msteams`).
* `CommandReceiver API` - `he` exposes a `REST API` that allows products
  to request commands / actions on `he` and the `chat platform`.
* `Authentication / Login` - `he` has built-in support for product 
  _scripts_ that need to provide a login portal to chat platform users
  in order to authenticate against their product and securly cache
  credentials.

## Scripting in Hubot Enterprise

The Hubot Enterprise is a `bot` in its own right, that provides 
bot developers the capability to _teach it more behavior_ by _extending_
it using **scripts** (sometimes called _integrations_). By doing this,
Hubot Enterprise obviates the need for developers to create a bot 
from scratch, and instead allows them to focus on its _behavior_ and 
_functionality_.

In order to create a `bot` for your product, you just need to create
scripts that follow Hubot Enterprise's conventions and APIs. In the 
following sections we will show you how to build such scripts.

### Setup Hubot Enterprise

> Follow the instructions in the [Getting Started Guide](getting_started.md).
> Once you have `he` running it is time to write your first script.

### Writing your first script

- You need to use the following languages / technologies: 
  * `nodejs` version `v6.9+` 
  * `coffeescript` or `es6`

  > If you do not have those dependencies installed yet, please 
  > visit the [Getting Started Guide](getting_started.md) before going
  > any further.

- Initialize a `nodejs` project with `yarn`:

  Assuming that you have a directory in your machine called `/myprojects`
  and you want to create a new _product script_ called `he-myproduct`:

    ```bash
    mkdir /myprojects/he-myproduct
    cd /myproducts/he-myproduct
    yarn init .
    ```

- Answer the questions in the prompt related to your project. Here is an example:

    ```bash
    ➜  he-myproduct yarn init .    
    yarn init v0.21.3
    question name (he-myproduct): 
    question version (1.0.0): 
    question description: myproduct bot script
    question entry point (index.js): index.coffee
    question repository url: https://github.hpe.com/he-chatops/he-myproduct
    question author: Jane Smith
    question license (MIT): Hewlett-Packard Enterprise Develoment LP
    success Saved package.json
    Done in 131.38s.
    ```

- Inspect the `package.json` file created. Here is an example:

    ```json
    {
      "name": "he-myproduct",
      "version": "1.0.0",
      "description": "myproduct bot script",
      "main": "index.coffee",
      "repository": "https://github.hpe.com/he-chatops/he-myproduct",
      "author": "Jane Smith",
      "license": "Hewlett-Packard Enterprise Develoment LP"
    }
    ```

- Create the entry file for the project, which is listed as `main` in
  the `package.json` file. Here is an example:

    ```bash
    ➜  he-myproduct ls
    index.coffee  package.json
    ➜  he-myproduct
    ```

- Use `git` and `github` to add source control management to your projects.

    ```bash
    ➜  he-myproduct git init .
    Initialized empty Git repository in /home/ricardo/workspace/hpe-chatops/myprojects/he-myproduct/.git/
    ➜  he-myproduct git:(master) ✗ git add .    
    ➜  he-myproduct git:(master) ✗ git commit -a
    Aborting commit due to empty commit message.
    ➜  he-myproduct git:(master) ✗ git commit -m "Project skeleton"
    [master (root-commit) abfb7b7] Project skeleton
    2 files changed, 12 insertions(+)
    create mode 100644 index.coffee
    create mode 100644 package.json
    ```
 
- Create your product script's _main_ function in the main file.
  For instance, in the following example we create a sample 
  boilerplate code for the `index.coffee`:

    ```coffeescript
    _ = require 'lodash'
    logger = require 'winston'
    logger.info 'MyProduct Script'
    module.exports = (robot) ->
      messages = [
        "Hello",
        "World!"
      ]
      message = _.join messages, ' '
      robot.logger.info message
    
    ```

  When `he` loads this project, it will start by calling `require`
  on the `index.coffee` file which will do the following:
    * It will execute any code at the parent scope of the source file.
      In the example above, the execution will be the following:
      * `_ = require 'winston'`
      * `logger = require 'winston'`
      * `logger.info 'MyProduct Script'`
      * `module.exports = (robot) ->`
    * In the `module.exports = (robot) ->` line it will only _instantiate_
      the _anonymous function_ and assign it / export it to this module.
      The code inside the scope of this function is not executed yet.
  Once the module is _required_ then `he` will execute the exported
  function and pass it the `robot` object which is an internal representation
  of the `bot`. This object provides access to several runtime information
  and other static APIs. 


  > **Important note:** Please remember that `nodejs` is a _non-blocking / asynchronous_
  > execution virtual machine, and as such the execution of statements
  > in different scopes is not guaranteed to be _sequential_. Therefore,
  > if you need to have sequential execution you must use `callbacks` or
  > our recommendation is to use `Promises` to chain your asynchronous calls.

- Load your script in `he` with one of two methods:
  1. You could move your product script's folder to the `./scripts`
    directory in the hubot enterprise code structure. Alternatively,
    you could create a `symlink` from your product script's folder
    to this directory 
    (e.g. `ln -s /myprojects/he-myproduct /my/path/to/hubot-enterprise/scripts/he-myproduct`)
  2. Or, you could provide the _full path_ for the folder of your 
    product script using the `HUBOT_SCRIPTS` environment variable. To set this
    environment variable you could do one of the following:
    * Perform an `export HUBOT_SCRIPTS="<path>"` in the shell in which you will be
      running `he`.
    * Or, in case that you used the configuration script, you can answer the following
      question with the entire path of your product script:
      
      ```bash
      # TODO:
      ```
      
      This will generate one (or more) files using the `<platform>.env` naming convention 
      (e.g. `slack.env`, `mattermost.env`). You may also edit these files directly if you
      do not want to _re-run_ the configuration script.
  
### Adding script commands / listeners

- Explain `robot.e.create` vs. regular `robot.listen` and `robot.respond`.
- Syntax of command 
- Configuration attributions / options

## Unified Bot Communication

### Hubot vs. Hubot Enterprise

- Explain the concept of the `adapter`.
- Explain that adapters differ from each other, inconsitent API.
- What is the `UnifiedAdapter`.

![Unified Adapter Communication](assets/he_unified_adapter_comm.png)

### Bot-to-chat platform communication

- Explain the `UnifiedAdapter` chat platform public API.
- Explain the `UnifiedAdapter` render API

### Bot-to-product communication 

- Explain the secure communications.

### Product-to-bot communication

- Executing chat platform commands
    - What are the public APIs available
- Executing product script commands
    - How do you setup the commands via `http` / `REST`?
 
## Writing Unified adapters

 - How to subclass
 - The interface enforced
 - Required private API that needs to be implemented.
 - Supported public API

