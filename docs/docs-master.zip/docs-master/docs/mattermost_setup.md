# Setting up MatterMost Server

> **NOTE**: we are **only** supporting the linux version of the
> mattermost server version `3.6`.



## Using the linux version of MatterMost
* Follow the instructions [here](https://docs.mattermost.com/install/install-rhel-71.html)

## Using the docker version of MatterMost
>**Note: this method of installing MatterMost is not supported**

* Clone the mattermost-docker repository:
  `git clone https://github.com/mattermost/mattermost-docker.git`

* Move to the mattermost-docker repository:
  `cd mattermost-docker`

You should be now in `master` branch if you do a `git branch`.

* You should not use the version in `master`. Instead you should 
  checkout the tag for the supported versions listed above:
  
  ```
  # To checkout version 3.6
  git checkout tags/3.6
  ```

* Create a file called `dc.proxy.yaml` which contains the following:

```yaml
version: '2'
services:
  db:
    build:
      context: db
      args:
        - http_proxy=$http_proxy
        - https_proxy=$https_proxy
        - ftp_proxy=$ftp_proxy
        - no_proxy=$no_proxy
        - HTTP_PROXY=$HTTP_PROXY
        - HTTPS_PROXY=$HTTPS_PROXY
        - FTP_PROXY=$FTP_PROXY
        - NO_PROXY=$NO_PROXY
    environment:
        - http_proxy=$http_proxy
        - https_proxy=$https_proxy
        - ftp_proxy=$ftp_proxy
        - no_proxy=$no_proxy
        - HTTP_PROXY=$HTTP_PROXY
        - HTTPS_PROXY=$HTTPS_PROXY
        - FTP_PROXY=$FTP_PROXY
        - NO_PROXY=$NO_PROXY

  app:
    build:
      context: app
      args:
        - http_proxy=$http_proxy
        - https_proxy=$https_proxy
        - ftp_proxy=$ftp_proxy
        - no_proxy=$no_proxy
        - HTTP_PROXY=$HTTP_PROXY
        - HTTPS_PROXY=$HTTPS_PROXY
        - FTP_PROXY=$FTP_PROXY
        - NO_PROXY=$NO_PROXY
    environment:
        - http_proxy=$http_proxy
        - https_proxy=$https_proxy
        - ftp_proxy=$ftp_proxy
        - no_proxy=$no_proxy
        - HTTP_PROXY=$HTTP_PROXY
        - HTTPS_PROXY=$HTTPS_PROXY
        - FTP_PROXY=$FTP_PROXY
        - NO_PROXY=$NO_PROXY

  web:
    build:
      context: web
      args:
        - http_proxy=$http_proxy
        - https_proxy=$https_proxy
        - ftp_proxy=$ftp_proxy
        - no_proxy=$no_proxy
        - HTTP_PROXY=$HTTP_PROXY
        - HTTPS_PROXY=$HTTPS_PROXY
        - FTP_PROXY=$FTP_PROXY
        - NO_PROXY=$NO_PROXY
    environment:
        - http_proxy=$http_proxy
        - https_proxy=$https_proxy
        - ftp_proxy=$ftp_proxy
        - no_proxy=$no_proxy
        - HTTP_PROXY=$HTTP_PROXY
        - HTTPS_PROXY=$HTTPS_PROXY
        - FTP_PROXY=$FTP_PROXY

        - NO_PROXY=$NO_PROXY 
```

* Make sure your environment variables are properly setup.

* Build the images:
`docker-compose -f docker-compose.yml -f dc.proxy.yml build --no-cache`

* Start your MatterMost server:
`docker-compose -f docker-compose.yml -f dc.proxy.yml up`

>Note: Dont worry if you see some errors from the db_1 container. It still works well for testing.

* For more information visit the [MatterMost](https://about.mattermost.com/) website
