# command receiver

##robot.e.registerScript
In your code you need to register the callback function for general restAPI
 by calling robot.e.registerScript function:
```coffee
robot.e.registerScript integration_name , script_name , callback
```

* integration_name: "the name of your integration"
* script_name: "the  name of you script"
* callback: "the  function for general restAPI"

Example:
```coffee
  # register function
  robot.e.registerScript integration_name, 'createRoom' , (info, callback) ->                                                               
```

##restAPI
The restAPI can receive a http request with the POST way , it started with the Hubot Enterprise startup. 
And it listens on the port specified by the EXPRESS_PORT or PORT environment variables (preferred in that order) and defaults to 8080

You can use the following template to visit the restAPI,example:
```coffee
  curl -X POST -H "Content-Type:application/json" -d '{"channel_name": "test-channel","purpose": "for test","topic": "test"}' http://127.0.0.1:8000/urest/v1/script/{integration_name}/createRoom
```




  


