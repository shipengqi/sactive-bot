# Contribution Guidelines

# Testing

## Mocking third-party APIs

We use `nock` [recording](https://github.com/node-nock/nock#recording)
to intercept and mock all the third-party service APIs (e.g. Slack API).

Example:
```coffee
# Include nock
slack = require 'nock'
adapter = new UnifiedSlackAdapter()

# Load interceptors
slack.load('./test/mock/slack.json')

# API call should be intercepted
adapter._postMessage(channel_id, 'something')
```

To add more interceptors

```coffee
# Create an interceptor for API route
interceptor = slack('https://slack.com:443')
  .post("/api/users.list")
  
# Remove the interceptor to allow the API call to go through
slack.removeInterceptor interceptor

rec_options =
  output_objects: true
  
# Record request / response
slack.recorder.rec rec_options

# Print all intercepted calls and copy to JSON file (or write to file).
console.log(JSON.stringify(slack.recorder.play(), ' ', 2))
```

# Documentation

## Documenting your code

Hubot enterprise code should be documented using the `jsdoc 3` 
[format](http://usejsdoc.org/). Since we are using `coffeescript` and
not `javascript`, we need to modify the comment formatting to match
`coffeescript`'s convention. 

```coffeescript
###*
 * Function to calculate cube of input
 * @param {number} Number to operate on
 * @return {number} Cube of input
 ###
 cube = (x) -> x*x*x
```

Will generate the following `jsdoc` comments in `javascript`:

```js
/**
 * Function to calculate cube of input
 * @param {number} Number to operate on
 * @return {number} Cube of input
*/

cube = function(x) {
  return x * x * x;
};
```

Thus, you must use 

## Generating docs

Issue `npm run dist`, which will generate a documentation under 
`./dist/docs`. The documentation is namespaced using the git tag and
commit id. There should be a `index.html` file in the root of the 
generated documentation, open it with your favorite browser and enjoy!
