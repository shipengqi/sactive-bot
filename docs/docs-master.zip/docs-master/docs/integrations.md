# Using your own integrations

There are two supported methods to load `hubot` and Hubot Enterprise
integrations:

1. Write one or more `*.coffee` scripts and copy them into the
  `scripts` directory (e.g. `/hubot-enterprise/scripts`). 
  They are loaded in alphabetical order.
2. Write an integration in a directory (e.g. `/my_integration`) and
  load it by adding it to the `HUBOT_SCRIPTS` environment variable. 
  You can add more than one directory separated by spaces. Example:
  
```bash
# Setup other environment variables as instructed in other docs
...
# Add integration directories
export HUBOT_SCRIPTS="/my_integration /my_other_integration"
# Run HE
./run.sh
```

> **NOTE**: other methods like reading from `external-package.json`
> or using `--scripts` flag **are no longer supported**.

In your code you need to register the integration using the following function:
```coffee
options = 
  short_desc: "short description of your integration"
  long_desc: "long description of your integration(optional)"
  name: "the name of your integration, must not be the same name as another integration"
robot.e.registerIntegration options
```

You can use the following template to base your integrations:
```coffee
module.exports = (robot) ->
  # check that hubot-enterprise is loaded
  if not robot.e
    robot.logger.error 'hubot-enterprise not present, cannot run'
    return

  callback_function = (msg,_robot) ->
    msg.reply "Than you for your message"
    robot.logger.info "this is a log"

  # register integration
  options =
    short_desc: "sample integration"
    long_desc: "an integration that does not do anything, but serves as a template"
    name: "sm"
  robot.e.registerIntegration options

  # register hubot enterprise functions
  command_options = 
    verb: 'info'
    example: 'this is a sample message'
    type: 'respond'
    help: 'this sample integration doesnt do anything'
    integration_name: 'sm'
  robot.e.create command_options, callback_function
```

In order to call a function from your integration just connect to your chat, and `@botname <integration_name> <verb>`.

> More integration samples can be found at [here](../example/)


# Enable your authentication

To enable the authentication, in your code you need to register the integration and authentication using the following function:
```coffee
options = 
  short_desc: "short description of your integration"
  long_desc: "long description of your integration(optional)"
  name: "the name of your integration, must not be the same name as another integration"

auth_method = (username, password, callback) ->
  robot.logger.info "Authentication verification, and call for callback function"
  # Perform auth method
  if err
    return callback(err, null) if callback
  return callback(null, resp) if callback

# authentication:
#  adapter: the name of authentication adapter, e.g: 'basic_authentication_adapter'
#  HUBOT_DEFAULT_TOKEN_TTL: (optional) Default to 30 minute token expiration.
#  auth_method: (optional) the function defined by IntegrationScript for 'basic_authentication_adapter'
authentication =
  adapter: 'basic_authentication_adapter',
  HUBOT_DEFAULT_TOKEN_TTL: 1800,
  auth_method : auth_method
  
robot.e.registerIntegration options, authentication
```
