# Packaging and Distribution

## Generating docs 

Run the following command:

```bash
npm run dist
```

This will create a `./dist/docs` folder which 
should contain the different versions of the docs that are generating using `jsdoc`.

Go into one of these directories and open the `index.html` file with your browser.
You should see the documentation displayed as an HTML page.

> A `./dist/js_src` directory is also created in order to
> pre-process the `coffeescript` code into `javascript`
> before generating the docs with `jsdoc`.
 
## Packaging as RPM

Run the following command:

```bash
npm run build-rpm-pkg 
```

This will create a an `rpm` file under `./dist/rpm` named with the
following convention: `hubot-enterprise-<version>-<release>.<arch>.rpm`.
