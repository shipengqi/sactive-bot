# Using the startup script
Run the following command:
`coffee configure.coffee`

You will be prompted about which integration you want to use (currently mattermost and slack are the only ones available).
Then you will be asked for the values of the environment variables relevant to the chosen integration.

For the list of environment variables see the following pages:
[Slack](slack.md)
[MatterMost](mattermost.md)

If a `.env` file is found, those values are used by default.
If you want to write such a file beforehand, you need to follow the following format:
```
MY_ENV_VARIABLENAME=MY_VALUE
```
>Note: There must be no spaces between the equal sign and the variable name and the value.

Once you're done setting up the values, they are saved in the corresponding `.env` file. The file for mattermost is called mattermost.env and he file for slack is called slack.env.