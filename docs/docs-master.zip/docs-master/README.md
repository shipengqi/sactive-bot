# hubot-enterprise


Instructions are provided depending on adapter used:

* [Using HE with Slack](docs/slack.md)
* [Using HE with Mattermost](docs/mattermost.md)
* [Loading your scripts / integrations to HE](docs/integrations.md)
* [Guidelines to contribute code to this repo](docs/contrib.md)
* [Installation](docs/installation.md)
* [Packaging and distribution](docs/dist.md)
* [Configuration script](docs/configure.md)
* [Developer Guide](docs/developer_guide.md)